import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import {
    deleteDocument,
    getDocument,
    getDocumentIntelligence,
    getDocumentProcessing,
    listAllDocumentIntelligence,
    listDocuments,
    streamDocument,
    uploadDocument,
    uploadDocumentsBulk,
} from '../controllers/documentsController';

const tmpDir = path.join(process.cwd(), 'uploads', '_tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const upload = multer({
    dest: tmpDir,
    limits: { fileSize: 50 * 1024 * 1024 },
});

const router = Router();

router.use(authenticate);
router.get('/', listDocuments);
router.get('/intelligence/all', listAllDocumentIntelligence);
router.post('/bulk', upload.array('files', 20), uploadDocumentsBulk);
router.get('/:id/preview', streamDocument('inline'));
router.get('/:id/download', streamDocument('attachment'));
router.get('/:id/intelligence', getDocumentIntelligence);
router.get('/:id/processing', getDocumentProcessing);
router.get('/:id', getDocument);
router.post('/', upload.single('file'), uploadDocument);
router.delete('/:id', deleteDocument);

export default router;
