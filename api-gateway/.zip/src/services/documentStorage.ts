import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import Document from '../models/Document';
import DocumentChunk from '../models/DocumentChunk';
import { isAllowedFile, sanitizeFilename } from '../utils/fileValidation';
import { AuthUser } from './accessScope';
import {
    isAiServiceEnabled,
    resolveAiOrganizationId,
    uploadDocumentToAi,
} from './aiServiceClient';
import logger from '../utils/logger';

export const UPLOAD_ROOT = path.join(process.cwd(), 'uploads');

export function ensureUploadDir() {
    if (!fs.existsSync(UPLOAD_ROOT)) {
        fs.mkdirSync(UPLOAD_ROOT, { recursive: true });
    }
}

export function getDocumentDir(orgFolder: string, documentId: string) {
    return path.join(UPLOAD_ROOT, 'orgs', orgFolder, 'documents', documentId);
}

export function deleteDocumentFolder(storagePath: string) {
    const dir = path.dirname(storagePath);
    if (fs.existsSync(dir)) {
        fs.rmSync(dir, { recursive: true, force: true });
    }
}

export async function deleteDocumentFully(documentId: string, storagePath: string) {
    deleteDocumentFolder(storagePath);
    await DocumentChunk.deleteMany({ documentId });
    await Document.deleteOne({ documentId });
}

export interface UploadFileInput {
    path: string;
    originalname: string;
    mimetype: string;
    size: number;
}

export async function saveUploadedFile(user: AuthUser, file: UploadFileInput) {
    const validation = isAllowedFile(file.originalname, file.mimetype);
    if (!validation.ok) {
        if (fs.existsSync(file.path)) fs.unlinkSync(file.path);
        throw Object.assign(new Error(validation.reason), { statusCode: 415 });
    }

    const documentId = `doc_${uuidv4()}`;
    const orgFolder = user.organizationId || `personal_${user.userId}`;
    const destDir = getDocumentDir(orgFolder, documentId);
    fs.mkdirSync(destDir, { recursive: true });

    const storedFilename = sanitizeFilename(file.originalname);
    const storagePath = path.join(destDir, storedFilename);
    fs.renameSync(file.path, storagePath);

    const contentHash = crypto.createHash('sha256').update(fs.readFileSync(storagePath)).digest('hex');

    let pythonDocumentId: string | null = null;
    let aiProcessingStatus: string | null = null;
    let aiErrorMessage: string | null = null;
    let status: 'uploaded' | 'processing' | 'failed' = 'uploaded';

    if (isAiServiceEnabled()) {
        try {
            const aiOrgId = resolveAiOrganizationId(user);
            const aiResult = await uploadDocumentToAi({
                filePath: storagePath,
                originalFilename: file.originalname,
                mimeType: file.mimetype,
                organizationId: aiOrgId,
                title: file.originalname,
            });
            pythonDocumentId = aiResult.id;
            aiProcessingStatus = aiResult.status;
            status = 'processing';
        } catch (e: any) {
            aiErrorMessage = e.message || 'AI upload failed';
            status = 'failed';
            logger.warn(`AI forward failed for ${documentId}: ${aiErrorMessage}`);
        }
    }

    const doc = await Document.create({
        documentId,
        organizationId: user.organizationId || null,
        uploadedBy: user.userId,
        openRemoteUserId: (user as any).openRemoteUserId || null,
        originalFilename: file.originalname,
        storedFilename,
        mimeType: file.mimetype,
        sizeBytes: file.size,
        storagePath,
        contentHash,
        pythonDocumentId,
        aiProcessingStatus,
        aiErrorMessage,
        status,
        classification: null,
        metadata: { source: 'web_upload', aiSynced: !!pythonDocumentId },
    });

    return doc;
}
