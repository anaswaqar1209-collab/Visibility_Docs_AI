import axios, { AxiosError } from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import logger from '../utils/logger';

const BASE_URL = (process.env.AI_SERVICE_URL || 'http://localhost:8000').replace(/\/$/, '');
const TIMEOUT = parseInt(process.env.AI_SERVICE_TIMEOUT_MS || '120000', 10);
const ENABLED = process.env.AI_SERVICE_ENABLED !== 'false';

export function isAiServiceEnabled(): boolean {
    return ENABLED;
}

function client() {
    return axios.create({
        baseURL: BASE_URL,
        timeout: TIMEOUT,
        validateStatus: () => true,
    });
}

export function resolveAiOrganizationId(user: {
    organizationId?: string | null;
    userId: string;
}): string {
    return user.organizationId || `personal_${user.userId}`;
}

export type AiUploadResult = {
    id: string;
    title: string;
    status: string;
    message: string;
};

export async function uploadDocumentToAi(params: {
    filePath: string;
    originalFilename: string;
    mimeType: string;
    organizationId: string;
    title?: string;
}): Promise<AiUploadResult> {
    if (!ENABLED) {
        throw new Error('AI service is disabled');
    }

    const form = new FormData();
    form.append('file', fs.createReadStream(params.filePath), {
        filename: params.originalFilename,
        contentType: params.mimeType,
    });
    form.append('organization_id', params.organizationId);
    form.append('title', params.title || params.originalFilename);

    const res = await client().post('/api/v1/documents/upload', form, {
        headers: form.getHeaders(),
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
    });

    if (res.status >= 400) {
        const detail = res.data?.detail || res.data?.message || JSON.stringify(res.data);
        throw new Error(`AI upload failed (${res.status}): ${detail}`);
    }

    return res.data as AiUploadResult;
}

export type AiChatResult = {
    answer: string;
    sources: Array<Record<string, unknown>>;
    document_id: string;
    session_id?: string;
};

export async function chatWithAi(params: {
    organizationId: string;
    question: string;
    documentIds?: string[];
    sessionId?: string;
    chatHistory?: Array<{ role: string; content: string }>;
}): Promise<AiChatResult> {
    if (!ENABLED) {
        throw new Error('AI service is disabled');
    }

    const body: Record<string, unknown> = {
        organization_id: params.organizationId,
        question: params.question,
    };
    if (params.documentIds?.length) body.document_ids = params.documentIds;
    if (params.sessionId) body.session_id = params.sessionId;
    if (params.chatHistory?.length) body.chat_history = params.chatHistory;

    const path = params.documentIds?.length ? '/api/v1/chat' : '/api/v1/chat/all';
    const res = await client().post(path, body);

    if (res.status >= 400) {
        const detail = res.data?.detail || res.data?.message || JSON.stringify(res.data);
        throw new Error(`AI chat failed (${res.status}): ${detail}`);
    }

    return res.data as AiChatResult;
}

export type AiSearchResult = {
    results: Array<{
        document_id: string;
        document_title: string;
        document_type?: string;
        chunk_text: string;
        page_number?: number;
        score: number;
        metadata?: Record<string, unknown>;
    }>;
    total: number;
    query: string;
};

export async function searchWithAi(params: {
    organizationId: string;
    query: string;
    documentType?: string;
    limit?: number;
    offset?: number;
}): Promise<AiSearchResult> {
    if (!ENABLED) {
        throw new Error('AI service is disabled');
    }

    const res = await client().post('/api/v1/search', {
        query: params.query,
        organization_id: params.organizationId,
        document_type: params.documentType || undefined,
        limit: params.limit ?? 20,
        offset: params.offset ?? 0,
    });

    if (res.status >= 400) {
        const detail = res.data?.detail || res.data?.message || JSON.stringify(res.data);
        throw new Error(`AI search failed (${res.status}): ${detail}`);
    }

    return res.data as AiSearchResult;
}

export type AiJobStatus = {
    document_id?: string;
    status?: string;
    stage?: string;
    progress?: number;
    error?: string;
    [key: string]: unknown;
};

export async function getDocumentJobStatus(
    pythonDocumentId: string,
    organizationId?: string
): Promise<AiJobStatus | null> {
    if (!ENABLED || !pythonDocumentId) return null;

    try {
        const params = organizationId ? { organization_id: organizationId } : {};
        const res = await client().get(`/api/v1/documents/${pythonDocumentId}/job`, { params });
        if (res.status >= 400) return null;
        return res.data as AiJobStatus;
    } catch (e: any) {
        logger.warn(`AI job status fetch failed: ${e.message}`);
        return null;
    }
}

export type AiDocumentDetails = Record<string, unknown>;

export async function getAiDocument(
    pythonDocumentId: string,
    organizationId: string
): Promise<AiDocumentDetails | null> {
    if (!ENABLED || !pythonDocumentId) return null;

    const res = await client().get(`/api/v1/documents/${pythonDocumentId}`, {
        params: { organization_id: organizationId },
    });
    if (res.status >= 400) return null;
    return res.data as AiDocumentDetails;
}

export async function listAiValidations(
    organizationId: string,
    documentId?: string
): Promise<unknown[]> {
    if (!ENABLED) return [];

    const params: Record<string, string | number> = { organization_id: organizationId, limit: 50 };
    if (documentId) params.document_id = documentId;

    const res = await client().get('/api/v1/documents/validations/list', { params });
    if (res.status >= 400) return [];
    const data = res.data;
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.validations)) return data.validations;
    if (Array.isArray(data?.validation_results)) return data.validation_results;
    if (Array.isArray(data?.results)) return data.results;
    return [];
}

export type ChatSessionSummary = {
    id: string;
    organization_id: string;
    document_ids: string[];
    title: string;
    created_at?: string;
    updated_at?: string;
};

export type ChatSessionMessage = {
    id?: number;
    session_id?: string;
    role: string;
    content: string;
    sources?: Array<Record<string, unknown>>;
    created_at?: string;
};

export type ChatSessionDetails = ChatSessionSummary & {
    messages: ChatSessionMessage[];
};

export async function listChatSessions(organizationId: string): Promise<ChatSessionSummary[]> {
    if (!ENABLED) return [];

    const res = await client().get('/api/v1/chat/sessions', {
        params: { organization_id: organizationId },
    });
    if (res.status >= 400) return [];
    return (res.data?.sessions || []) as ChatSessionSummary[];
}

export async function getChatSession(sessionId: string): Promise<ChatSessionDetails | null> {
    if (!ENABLED || !sessionId) return null;

    const res = await client().get(`/api/v1/chat/sessions/${sessionId}`);
    if (res.status >= 400) return null;
    return res.data as ChatSessionDetails;
}

export async function deleteChatSession(sessionId: string): Promise<boolean> {
    if (!ENABLED || !sessionId) return false;

    const res = await client().delete(`/api/v1/chat/sessions/${sessionId}`);
    return res.status < 400;
}

export async function checkAiHealth(): Promise<boolean> {
    if (!ENABLED) return false;
    try {
        const res = await client().get('/health');
        return res.status === 200;
    } catch {
        return false;
    }
}

export function formatAiError(error: unknown): string {
    if (error instanceof AxiosError) {
        return error.response?.data?.detail || error.message;
    }
    if (error instanceof Error) return error.message;
    return 'AI service error';
}
