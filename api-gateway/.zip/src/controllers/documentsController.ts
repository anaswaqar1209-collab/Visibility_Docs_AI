import path from 'path';
import fs from 'fs';
import { Request, Response, NextFunction } from 'express';
import Document from '../models/Document';
import {
    buildDocumentFilter,
    canAccessDocument,
    canDeleteDocument,
} from '../services/accessScope';
import {
    annotateDuplicateCounts,
    getDuplicateDocumentIds,
    getDuplicateGroupSizes,
} from '../services/duplicateDetection';
import {
    deleteDocumentFully,
    ensureUploadDir,
    saveUploadedFile,
} from '../services/documentStorage';
import { getDocumentJobStatus, getAiDocument, isAiServiceEnabled, listAiValidations, resolveAiOrganizationId } from '../services/aiServiceClient';
import { PERMISSIONS } from '../types/permissions';
import { hasPermission } from '../services/accessScope';

const SORT_FIELDS: Record<string, string> = {
    createdAt: 'createdAt',
    name: 'originalFilename',
    size: 'sizeBytes',
    status: 'status',
};

const DONE_JOB_STATUSES = ['processed', 'completed', 'ready', 'embedded', 'extracted', 'classified'];

function applyJobStatusToDocument(doc: InstanceType<typeof Document>, job: Record<string, unknown> | null) {
    if (!job) return;
    const jobStatus = String(job.status || job.stage || '').toLowerCase();
    if (jobStatus && doc.aiProcessingStatus !== jobStatus) {
        doc.aiProcessingStatus = jobStatus;
    }
    if (DONE_JOB_STATUSES.some((s) => jobStatus.includes(s))) {
        doc.status = 'ready';
    } else if (jobStatus.includes('fail')) {
        doc.status = 'failed';
    } else if (jobStatus) {
        doc.status = 'processing';
    }
}

export const listDocuments = async (req: Request, res: Response, next: NextFunction) => {
    try {
        if (!hasPermission(req.user, PERMISSIONS.DOCUMENT_VIEW)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }

        const page = Math.max(1, parseInt((req.query.page as string) || '1', 10));
        const limit = Math.min(100, Math.max(1, parseInt((req.query.limit as string) || '20', 10)));
        const q = ((req.query.q as string) || '').trim();
        const sortBy = SORT_FIELDS[(req.query.sortBy as string) || 'createdAt'] || 'createdAt';
        const sortOrder = (req.query.sortOrder as string) === 'asc' ? 1 : -1;
        const status = (req.query.status as string) || '';
        const mimeType = (req.query.mimeType as string) || '';
        const organizationId = (req.query.organizationId as string) || undefined;
        const duplicatesOnly = (req.query.duplicatesOnly as string) === 'true';

        const extra: Record<string, unknown> = {};
        if (status) extra.status = status;
        if (mimeType) extra.mimeType = new RegExp(mimeType.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
        if (q) {
            extra.$or = [
                { originalFilename: { $regex: q, $options: 'i' } },
                { classification: { $regex: q, $options: 'i' } },
                { documentId: { $regex: q, $options: 'i' } },
            ];
        }

        const baseFilter = buildDocumentFilter(req.user, extra, { organizationId });
        let filter = baseFilter;

        if (duplicatesOnly) {
            const duplicateIds = await getDuplicateDocumentIds(baseFilter);
            if (!duplicateIds.length) {
                return res.json({
                    success: true,
                    data: {
                        documents: [],
                        pagination: { page: 1, limit, total: 0, totalPages: 0 },
                    },
                });
            }
            filter = { ...baseFilter, documentId: { $in: duplicateIds } };
        }

        const [documents, total, duplicateSizes] = await Promise.all([
            Document.find(filter)
                .sort({ [sortBy]: sortOrder })
                .skip((page - 1) * limit)
                .limit(limit)
                .lean(),
            Document.countDocuments(filter),
            getDuplicateGroupSizes(baseFilter),
        ]);

        res.json({
            success: true,
            data: {
                documents: annotateDuplicateCounts(documents, duplicateSizes),
                pagination: {
                    page,
                    limit,
                    total,
                    totalPages: Math.ceil(total / limit) || 0,
                },
            },
        });
    } catch (error) {
        next(error);
    }
};

export const getDocument = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const doc = await Document.findOne({ documentId: req.params.id });
        if (!doc) {
            return res.status(404).json({ success: false, message: 'Document not found' });
        }
        if (!canAccessDocument(req.user, doc)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }
        res.json({ success: true, data: { document: doc } });
    } catch (error) {
        next(error);
    }
};

export const streamDocument = (disposition: 'inline' | 'attachment') =>
    async (req: Request, res: Response, next: NextFunction) => {
        try {
            const perm = disposition === 'inline' ? PERMISSIONS.DOCUMENT_PREVIEW : PERMISSIONS.DOCUMENT_VIEW;
            if (!hasPermission(req.user, perm)) {
                return res.status(403).json({ success: false, message: 'Forbidden' });
            }

            const doc = await Document.findOne({ documentId: req.params.id });
            if (!doc) {
                return res.status(404).json({ success: false, message: 'Document not found' });
            }
            if (!canAccessDocument(req.user, doc)) {
                return res.status(403).json({ success: false, message: 'Forbidden' });
            }
            if (!fs.existsSync(doc.storagePath)) {
                return res.status(404).json({ success: false, message: 'File not found on disk' });
            }

            res.setHeader('Content-Type', doc.mimeType || 'application/octet-stream');
            res.setHeader(
                'Content-Disposition',
                `${disposition}; filename="${encodeURIComponent(doc.originalFilename)}"`
            );
            fs.createReadStream(doc.storagePath).pipe(res);
        } catch (error) {
            next(error);
        }
    };

export const uploadDocument = async (req: Request, res: Response, next: NextFunction) => {
    try {
        if (!hasPermission(req.user, PERMISSIONS.DOCUMENT_UPLOAD)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }
        ensureUploadDir();
        const file = req.file;
        if (!file) {
            return res.status(400).json({ success: false, message: 'No file uploaded' });
        }

        const doc = await saveUploadedFile(req.user, file);
        res.status(201).json({
            success: true,
            message: 'Document uploaded successfully',
            data: { document: doc },
        });
    } catch (error: any) {
        if (error.statusCode === 415) {
            return res.status(415).json({ success: false, message: error.message });
        }
        next(error);
    }
};

export const uploadDocumentsBulk = async (req: Request, res: Response, next: NextFunction) => {
    try {
        if (!hasPermission(req.user, PERMISSIONS.DOCUMENT_UPLOAD)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }
        ensureUploadDir();
        const files = (req.files as Express.Multer.File[]) || [];
        if (!files.length) {
            return res.status(400).json({ success: false, message: 'No files uploaded' });
        }

        const uploaded: any[] = [];
        const failed: { name: string; reason: string }[] = [];

        for (const file of files) {
            try {
                const doc = await saveUploadedFile(req.user, file);
                uploaded.push(doc);
            } catch (err: any) {
                failed.push({ name: file.originalname, reason: err.message || 'Upload failed' });
            }
        }

        res.status(uploaded.length ? 201 : 400).json({
            success: uploaded.length > 0,
            message: `Uploaded ${uploaded.length} file(s)${failed.length ? `, ${failed.length} failed` : ''}`,
            data: { uploaded, failed },
        });
    } catch (error) {
        next(error);
    }
};

export const getDocumentProcessing = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const doc = await Document.findOne({ documentId: req.params.id });
        if (!doc) {
            return res.status(404).json({ success: false, message: 'Document not found' });
        }
        if (!canAccessDocument(req.user, doc)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }

        let aiJob = null;
        const orgId = resolveAiOrganizationId(req.user);
        if (isAiServiceEnabled() && doc.pythonDocumentId) {
            aiJob = await getDocumentJobStatus(doc.pythonDocumentId, orgId);
            applyJobStatusToDocument(doc, aiJob);
            await doc.save();
        }

        res.json({
            success: true,
            data: {
                documentId: doc.documentId,
                pythonDocumentId: doc.pythonDocumentId,
                status: doc.status,
                aiProcessingStatus: doc.aiProcessingStatus,
                aiErrorMessage: doc.aiErrorMessage,
                job: aiJob,
            },
        });
    } catch (error) {
        next(error);
    }
};

export const getDocumentIntelligence = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const doc = await Document.findOne({ documentId: req.params.id });
        if (!doc) {
            return res.status(404).json({ success: false, message: 'Document not found' });
        }
        if (!canAccessDocument(req.user, doc)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }

        const orgId = resolveAiOrganizationId(req.user);
        let aiDocument = null;
        let job = null;
        let validations: unknown[] = [];

        if (isAiServiceEnabled() && doc.pythonDocumentId) {
            [aiDocument, job, validations] = await Promise.all([
                getAiDocument(doc.pythonDocumentId, orgId),
                getDocumentJobStatus(doc.pythonDocumentId, orgId),
                listAiValidations(orgId, doc.pythonDocumentId),
            ]);
        }

        res.json({
            success: true,
            data: {
                document: doc,
                aiDocument,
                job,
                validations,
            },
        });
    } catch (error) {
        next(error);
    }
};

export const listAllDocumentIntelligence = async (req: Request, res: Response, next: NextFunction) => {
    try {
        if (!hasPermission(req.user, PERMISSIONS.DOCUMENT_VIEW)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }

        const filter = buildDocumentFilter(req.user, {});
        const docs = await Document.find(filter).sort({ createdAt: -1 }).limit(100);
        const orgId = resolveAiOrganizationId(req.user);

        const documents = await Promise.all(
            docs.map(async (doc) => {
                let aiDocument = null;
                let job = null;
                let validations: unknown[] = [];

                if (isAiServiceEnabled() && doc.pythonDocumentId) {
                    job = await getDocumentJobStatus(doc.pythonDocumentId, orgId);
                    applyJobStatusToDocument(doc, job);
                    await doc.save();

                    if (doc.status === 'ready') {
                        [aiDocument, validations] = await Promise.all([
                            getAiDocument(doc.pythonDocumentId, orgId),
                            listAiValidations(orgId, doc.pythonDocumentId),
                        ]);
                    }
                }

                return {
                    document: doc.toObject(),
                    aiDocument,
                    job,
                    validations,
                };
            })
        );

        const summary = {
            total: documents.length,
            processing: documents.filter((d) =>
                d.document.status === 'processing' || d.document.status === 'uploaded'
            ).length,
            ready: documents.filter((d) => d.document.status === 'ready').length,
            failed: documents.filter((d) => d.document.status === 'failed').length,
        };

        res.json({ success: true, data: { summary, documents } });
    } catch (error) {
        next(error);
    }
};

export const deleteDocument = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const doc = await Document.findOne({ documentId: req.params.id });
        if (!doc) {
            return res.status(404).json({ success: false, message: 'Document not found' });
        }
        if (!canDeleteDocument(req.user, doc)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }

        await deleteDocumentFully(doc.documentId, doc.storagePath);
        res.json({ success: true, message: 'Document and folder deleted' });
    } catch (error) {
        next(error);
    }
};
