import { Request, Response, NextFunction } from 'express';
import Document from '../models/Document';
import { buildDocumentFilter, hasPermission } from '../services/accessScope';
import {
    chatWithAi,
    deleteChatSession,
    formatAiError,
    getChatSession,
    isAiServiceEnabled,
    listChatSessions,
    resolveAiOrganizationId,
} from '../services/aiServiceClient';
import { PERMISSIONS } from '../types/permissions';
import logger from '../utils/logger';

export const chatWithDocuments = async (req: Request, res: Response, next: NextFunction) => {
    try {
        if (!hasPermission(req.user, PERMISSIONS.CHAT_USE)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }

        const message = (req.body.message || req.body.query || req.body.question || '').toString().trim();
        const documentIds: string[] = Array.isArray(req.body.documentIds) ? req.body.documentIds : [];
        const chatScope = (req.body.chatScope || 'all').toString() as 'all' | 'selected';
        const sessionId = req.body.sessionId as string | undefined;

        if (!message) {
            return res.status(400).json({ success: false, message: 'message is required' });
        }

        if (chatScope === 'selected' && !documentIds.length) {
            return res.status(400).json({
                success: false,
                message: 'Select at least one document for selected chat scope',
            });
        }

        const filter = buildDocumentFilter(req.user, {});
        const docs = await Document.find(filter).sort({ createdAt: -1 }).limit(100).lean();

        if (!docs.length) {
            return res.json({
                success: true,
                data: {
                    reply: "I don't see any documents in your library yet. Upload a PDF or image on the Documents page, then ask again.",
                    citations: [],
                    model: 'docs-ai',
                },
            });
        }

        if (!isAiServiceEnabled()) {
            return res.json({
                success: true,
                data: {
                    reply: `AI service is offline. You have **${docs.length}** document(s) in your library. Start the Python AI service on port 8000 and try again.`,
                    citations: docs.slice(0, 3).map((d) => ({
                        documentId: d.documentId,
                        filename: d.originalFilename,
                        status: d.status,
                    })),
                    model: 'docs-ai-offline',
                },
            });
        }

        const pythonIdToDoc = new Map(
            docs.filter((d) => d.pythonDocumentId).map((d) => [d.pythonDocumentId as string, d])
        );
        const pythonDocumentIds = [...pythonIdToDoc.keys()];

        if (!pythonDocumentIds.length) {
            return res.json({
                success: true,
                data: {
                    reply: `Your documents are saved but not yet processed by the AI service. Re-upload after starting the AI backend, or wait for processing to complete.`,
                    citations: docs.slice(0, 5).map((d) => ({
                        documentId: d.documentId,
                        filename: d.originalFilename,
                        status: d.status,
                        pythonDocumentId: d.pythonDocumentId,
                    })),
                    model: 'docs-ai-pending',
                },
            });
        }

        try {
            const orgId = resolveAiOrganizationId(req.user);
            let scopedPythonIds: string[] | undefined;

            if (chatScope === 'selected') {
                scopedPythonIds = docs
                    .filter((d) => d.pythonDocumentId && documentIds.includes(d.documentId))
                    .map((d) => d.pythonDocumentId as string);
                if (!scopedPythonIds.length) {
                    return res.status(400).json({
                        success: false,
                        message: 'Selected documents are not processed by AI yet',
                    });
                }
            } else {
                scopedPythonIds = undefined;
            }

            const result = await chatWithAi({
                organizationId: orgId,
                question: message,
                documentIds: scopedPythonIds,
                sessionId,
                chatHistory: Array.isArray(req.body.chatHistory) ? req.body.chatHistory : undefined,
            });

            const citations = (result.sources || []).map((source: any) => {
                const nodeDoc = pythonIdToDoc.get(source.document_id || source.documentId);
                return {
                    documentId: nodeDoc?.documentId || source.document_id,
                    filename: nodeDoc?.originalFilename || source.document_title || source.title,
                    pageNumber: source.page_number,
                    score: source.score,
                    snippet: source.chunk_text || source.text,
                };
            });

            res.json({
                success: true,
                data: {
                    reply: result.answer,
                    citations,
                    sessionId: result.session_id,
                    chatScope,
                    model: 'visibility-ai-rag',
                },
            });
        } catch (aiError: any) {
            logger.error(`AI chat proxy failed: ${formatAiError(aiError)}`);
            return res.status(502).json({
                success: false,
                message: 'AI chat service unavailable',
                error: formatAiError(aiError),
            });
        }
    } catch (error) {
        next(error);
    }
};

export const listChatSessionsHandler = async (req: Request, res: Response, next: NextFunction) => {
    try {
        if (!hasPermission(req.user, PERMISSIONS.CHAT_USE)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }
        if (!isAiServiceEnabled()) {
            return res.json({ success: true, data: { sessions: [], total: 0 } });
        }
        const orgId = resolveAiOrganizationId(req.user);
        const sessions = await listChatSessions(orgId);
        res.json({ success: true, data: { sessions, total: sessions.length } });
    } catch (error) {
        next(error);
    }
};

export const getChatSessionHandler = async (req: Request, res: Response, next: NextFunction) => {
    try {
        if (!hasPermission(req.user, PERMISSIONS.CHAT_USE)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }
        if (!isAiServiceEnabled()) {
            return res.status(503).json({ success: false, message: 'AI service offline' });
        }
        const sessionId = String(req.params.id);
        const session = await getChatSession(sessionId);
        if (!session) {
            return res.status(404).json({ success: false, message: 'Session not found' });
        }
        const orgId = resolveAiOrganizationId(req.user);
        if (session.organization_id && session.organization_id !== orgId) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }
        res.json({ success: true, data: { session } });
    } catch (error) {
        next(error);
    }
};

export const deleteChatSessionHandler = async (req: Request, res: Response, next: NextFunction) => {
    try {
        if (!hasPermission(req.user, PERMISSIONS.CHAT_USE)) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }
        if (!isAiServiceEnabled()) {
            return res.status(503).json({ success: false, message: 'AI service offline' });
        }
        const sessionId = String(req.params.id);
        const existing = await getChatSession(sessionId);
        if (!existing) {
            return res.status(404).json({ success: false, message: 'Session not found' });
        }
        const orgId = resolveAiOrganizationId(req.user);
        if (existing.organization_id && existing.organization_id !== orgId) {
            return res.status(403).json({ success: false, message: 'Forbidden' });
        }
        const ok = await deleteChatSession(sessionId);
        if (!ok) {
            return res.status(502).json({ success: false, message: 'Failed to delete session' });
        }
        res.json({ success: true, message: 'Session deleted' });
    } catch (error) {
        next(error);
    }
};
