"use client";

import React, { useEffect, useRef, useState } from "react";
import { ChevronDown, Check } from "lucide-react";
import { cn } from "@/lib/utils";

export type FilterSelectOption = { value: string; label: string };

type FilterSelectProps = {
    label: string;
    value: string;
    onChange: (value: string) => void;
    options: FilterSelectOption[];
    className?: string;
    minWidth?: string;
    menuPlacement?: "top" | "bottom";
    hideLabel?: boolean;
};

export default function FilterSelect({
    label,
    value,
    onChange,
    options,
    className,
    minWidth = "min-w-[130px]",
    menuPlacement = "bottom",
    hideLabel = false,
}: FilterSelectProps) {
    const [open, setOpen] = useState(false);
    const rootRef = useRef<HTMLDivElement>(null);

    const selected = options.find((o) => o.value === value) || options[0];

    useEffect(() => {
        if (!open) return;
        const onDocClick = (e: MouseEvent) => {
            if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
                setOpen(false);
            }
        };
        const onKey = (e: KeyboardEvent) => {
            if (e.key === "Escape") setOpen(false);
        };
        document.addEventListener("mousedown", onDocClick);
        document.addEventListener("keydown", onKey);
        return () => {
            document.removeEventListener("mousedown", onDocClick);
            document.removeEventListener("keydown", onKey);
        };
    }, [open]);

    return (
        <div ref={rootRef} className={cn("flex flex-col gap-1 relative", className)}>
            {!hideLabel && label && (
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 ml-0.5">
                    {label}
                </span>
            )}
            <div className={cn("relative", minWidth)}>
                <button
                    type="button"
                    onClick={() => setOpen((v) => !v)}
                    className={cn(
                        "premium-input w-full rounded-xl py-2.5 pl-3 pr-9 text-sm text-left",
                        "flex items-center justify-between gap-2",
                        open && "border-blue-500/60 ring-2 ring-blue-500/20"
                    )}
                    aria-haspopup="listbox"
                    aria-expanded={open}
                >
                    <span className="truncate">{selected?.label}</span>
                    <ChevronDown
                        size={14}
                        className={cn(
                            "absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 transition-transform shrink-0",
                            open && "rotate-180"
                        )}
                    />
                </button>

                {open && (
                    <ul
                        role="listbox"
                        className={cn(
                            "absolute left-0 right-0 z-[100] glass rounded-xl border border-white/10 shadow-xl py-1 max-h-56 overflow-y-auto",
                            menuPlacement === "top"
                                ? "bottom-[calc(100%+6px)]"
                                : "top-[calc(100%+6px)]"
                        )}
                    >
                        {options.map((opt) => {
                            const active = opt.value === value;
                            return (
                                <li key={opt.value || "__all__"} role="option" aria-selected={active}>
                                    <button
                                        type="button"
                                        onClick={() => {
                                            onChange(opt.value);
                                            setOpen(false);
                                        }}
                                        className={cn(
                                            "w-full text-left px-3 py-2 text-sm flex items-center justify-between gap-2 transition-colors",
                                            active
                                                ? "bg-blue-500/20 text-blue-200"
                                                : "text-slate-200 hover:bg-white/5"
                                        )}
                                    >
                                        <span>{opt.label}</span>
                                        {active && <Check size={14} className="text-blue-300 shrink-0" />}
                                    </button>
                                </li>
                            );
                        })}
                    </ul>
                )}
            </div>
        </div>
    );
}
