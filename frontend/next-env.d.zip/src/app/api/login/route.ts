import { NextRequest, NextResponse } from "next/server";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5100/api";

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();
        const res = await fetch(`${API_URL}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                identifier: body.email || body.identifier || body.username,
                password: body.password,
            }),
        });

        const data = await res.json();
        if (!res.ok) {
            return NextResponse.json(
                { error: data.message || "Login failed" },
                { status: res.status }
            );
        }

        return NextResponse.json(data);
    } catch (error: any) {
        return NextResponse.json(
            { error: error.message || "Login failed" },
            { status: 500 }
        );
    }
}
