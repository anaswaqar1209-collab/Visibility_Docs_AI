"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
    FileText, Upload, Trash2, RefreshCw, Eye, Search, FolderUp, Copy, X, Loader2, Info,
} from "lucide-react";
import ClientLayout from "@/components/ClientLayout";
import FilterSelect from "@/components/FilterSelect";
import LibraryPagination from "@/components/LibraryPagination";
import { useTheme } from "@/context/ColorContext";
import { apiRequest } from "@/lib/apiClient";
import {
    ACCEPT_ATTR,
    FILE_TYPE_MIME,
    FILE_TYPE_OPTIONS,
    filterAllowedFiles,
    getFileTypeLabel,
} from "@/lib/fileValidation";

type DocItem = {
    documentId: string;
    originalFilename: string;
    mimeType: string;
    sizeBytes: number;
    status: string;
    classification?: string | null;
    createdAt: string;
    duplicateCount?: number;
    isDuplicate?: boolean;
    pythonDocumentId?: string | null;
    aiProcessingStatus?: string | null;
    aiErrorMessage?: string | null;
};

type Pagination = { page: number; limit: number; total: number; totalPages: number };

type PendingFile = { id: string; file: File };

type QueueItemStatus = "queued" | "uploading" | "processing" | "done" | "error";

type QueueItem = {
    id: string;
    name: string;
    size: number;
    mimeType: string;
    status: QueueItemStatus;
    error?: string;
    documentId?: string;
};

const SORT_OPTIONS = [
    { value: "createdAt", label: "Date" },
    { value: "name", label: "Name" },
    { value: "size", label: "Size" },
];

const ORDER_OPTIONS = [
    { value: "desc", label: "Newest first" },
    { value: "asc", label: "Oldest first" },
];

const DUPLICATE_OPTIONS = [
    { value: "", label: "All files" },
    { value: "true", label: "Duplicates only" },
];

function formatBytes(n: number) {
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function statusBadge(status: string, isDark: boolean) {
    const s = status.toLowerCase();
    if (s === "ready" || s === "processed" || s === "completed") {
        return isDark ? "bg-green-500/15 text-green-300 border-green-500/25" : "bg-green-100 text-green-700 border-green-200";
    }
    if (s === "processing" || s === "uploaded") {
        return isDark ? "bg-amber-500/15 text-amber-300 border-amber-500/25" : "bg-amber-100 text-amber-700 border-amber-200";
    }
    if (s === "failed" || s.includes("fail") || s.includes("error")) {
        return isDark ? "bg-red-500/15 text-red-300 border-red-500/25" : "bg-red-100 text-red-700 border-red-200";
    }
    return isDark ? "bg-slate-500/15 text-slate-300 border-slate-500/25" : "bg-slate-100 text-slate-600 border-slate-200";
}

const IN_PROGRESS_AI = ["queued", "running", "processing", "ocr", "classify", "extract", "embed", "uploaded", "pending"];

function getDisplayStatus(doc: DocItem): { label: string; isProcessing: boolean; subtitle?: string } {
    if (doc.status === "failed" || (doc.aiErrorMessage && !doc.pythonDocumentId)) {
        return { label: "Failed", isProcessing: false };
    }
    if (doc.status === "ready") {
        return { label: "Ready", isProcessing: false };
    }
    const ai = (doc.aiProcessingStatus || "").toLowerCase();
    if (ai.includes("fail")) {
        return { label: "Failed", isProcessing: false, subtitle: doc.aiProcessingStatus || undefined };
    }
    if (doc.status === "processing" || doc.status === "uploaded") {
        const inProgress = !ai || IN_PROGRESS_AI.some((s) => ai.includes(s));
        if (inProgress) {
            return {
                label: "Processing",
                isProcessing: true,
                subtitle: doc.aiProcessingStatus && doc.aiProcessingStatus !== "processing" ? doc.aiProcessingStatus : undefined,
            };
        }
    }
    if (doc.status === "uploaded") {
        return { label: "Uploaded", isProcessing: false };
    }
    return { label: doc.status, isProcessing: doc.status === "processing" };
}

function DocumentsContent() {
    const { theme } = useTheme();
    const colors = theme.colors;
    const isDark = theme.name === "dark";
    const containerRef = useRef<HTMLDivElement>(null);

    const [docs, setDocs] = useState<DocItem[]>([]);
    const [pagination, setPagination] = useState<Pagination>({ page: 1, limit: 10, total: 0, totalPages: 0 });
    const [loading, setLoading] = useState(true);
    const [uploading, setUploading] = useState(false);
    const [dragOver, setDragOver] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);
    const [queueItems, setQueueItems] = useState<QueueItem[]>([]);

    const [q, setQ] = useState("");
    const [searchInput, setSearchInput] = useState("");
    const [sortBy, setSortBy] = useState("createdAt");
    const [sortOrder, setSortOrder] = useState("desc");
    const [fileTypeFilter, setFileTypeFilter] = useState("");
    const [duplicatesOnly, setDuplicatesOnly] = useState("");
    const [page, setPage] = useState(1);
    const [pageLimit, setPageLimit] = useState(10);

    const applySearch = () => {
        setQ(searchInput);
        setPage(1);
    };

    const load = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const params = new URLSearchParams({
                page: String(page),
                limit: String(pageLimit),
                sortBy,
                sortOrder,
            });
            if (q) params.set("q", q);
            if (fileTypeFilter && FILE_TYPE_MIME[fileTypeFilter]) {
                params.set("mimeType", FILE_TYPE_MIME[fileTypeFilter]);
            }
            if (duplicatesOnly === "true") params.set("duplicatesOnly", "true");
            const data = await apiRequest(`/docs/documents?${params}`);
            setDocs(data?.data?.documents || []);
            setPagination(data?.data?.pagination || { page: 1, limit: 10, total: 0, totalPages: 0 });
        } catch (e: any) {
            setError(e.message || "Failed to load documents");
        } finally {
            setLoading(false);
        }
    }, [page, pageLimit, q, sortBy, sortOrder, fileTypeFilter, duplicatesOnly]);

    useEffect(() => { load(); }, [load]);

    const processingDocIds = docs
        .filter((d) => d.status === "processing" || d.status === "uploaded")
        .map((d) => d.documentId);

    useEffect(() => {
        if (!processingDocIds.length) return;
        const interval = setInterval(async () => {
            let changed = false;
            const updates: Record<string, Partial<DocItem>> = {};
            await Promise.all(
                processingDocIds.map(async (id) => {
                    try {
                        const data = await apiRequest(`/docs/documents/${id}/processing`);
                        const proc = data?.data;
                        if (proc) {
                            updates[id] = {
                                status: proc.status,
                                aiProcessingStatus: proc.aiProcessingStatus,
                            };
                            changed = true;
                        }
                    } catch {
                        /* ignore poll errors */
                    }
                })
            );
            if (changed) {
                setDocs((prev) =>
                    prev.map((d) => (updates[d.documentId] ? { ...d, ...updates[d.documentId] } : d))
                );
            }
        }, 5000);
        return () => clearInterval(interval);
    }, [processingDocIds.join(",")]);

    const addFilesToQueue = (fileList: FileList | File[]) => {
        const { allowed, rejected } = filterAllowedFiles(fileList);
        if (rejected.length) {
            setError(`Rejected unsupported files: ${rejected.join(", ")}`);
        }
        if (!allowed.length) return;
        const newItems: PendingFile[] = allowed.map((file) => ({
            id: `pf_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
            file,
        }));
        setPendingFiles((prev) => [...prev, ...newItems]);
    };

    useEffect(() => {
        const onPaste = (e: ClipboardEvent) => {
            const files = e.clipboardData?.files;
            if (!files?.length) return;
            e.preventDefault();
            addFilesToQueue(files);
        };
        const el = containerRef.current;
        el?.addEventListener("paste", onPaste as any);
        return () => el?.removeEventListener("paste", onPaste as any);
    });

    const removeFromQueue = (id: string) => {
        setPendingFiles((prev) => prev.filter((p) => p.id !== id));
    };

    const clearQueue = () => setPendingFiles([]);

    const uploadQueue = async () => {
        if (!pendingFiles.length || uploading) return;
        setUploading(true);
        setError(null);

        const items: QueueItem[] = pendingFiles.map((p) => ({
            id: p.id,
            name: p.file.name,
            size: p.file.size,
            mimeType: p.file.type,
            status: "queued",
        }));
        setQueueItems(items);
        setPendingFiles([]);

        for (let i = 0; i < pendingFiles.length; i++) {
            const pf = pendingFiles[i];
            setQueueItems((prev) =>
                prev.map((q) => (q.id === pf.id ? { ...q, status: "uploading" } : q))
            );
            try {
                const form = new FormData();
                form.append("file", pf.file);
                const data = await apiRequest("/docs/documents", { method: "POST", body: form });
                const doc = data?.data?.document;
                const aiStatus = doc?.aiProcessingStatus || doc?.status || "processing";
                setQueueItems((prev) =>
                    prev.map((q) =>
                        q.id === pf.id
                            ? {
                                  ...q,
                                  status: aiStatus === "failed" ? "error" : "processing",
                                  documentId: doc?.documentId,
                                  error: doc?.aiErrorMessage || undefined,
                              }
                            : q
                    )
                );
            } catch (e: any) {
                setQueueItems((prev) =>
                    prev.map((q) =>
                        q.id === pf.id ? { ...q, status: "error", error: e.message } : q
                    )
                );
            }
        }

        await load();
        setUploading(false);
        setTimeout(() => setQueueItems([]), 6000);
    };

    const onDrop = (e: React.DragEvent) => {
        e.preventDefault();
        setDragOver(false);
        if (e.dataTransfer.files?.length) addFilesToQueue(e.dataTransfer.files);
    };

    const remove = async (id: string, name: string) => {
        if (!confirm(`Delete "${name}" and its folder permanently?`)) return;
        try {
            await apiRequest(`/docs/documents/${id}`, { method: "DELETE" });
            await load();
        } catch (e: any) {
            setError(e.message || "Delete failed");
        }
    };

    const showStaging = pendingFiles.length > 0 || queueItems.length > 0;

    return (
        <div ref={containerRef} tabIndex={0} className="p-6 lg:p-8 space-y-6 max-w-6xl mx-auto outline-none">
            <div>
                <h1 className={`text-2xl font-bold tracking-tight ${colors.textPrimary}`}>Documents</h1>
                <p className={`text-sm mt-1 ${colors.textMuted}`}>
                    Add files to queue, review, then upload. Files go to server then AI model automatically.
                </p>
                <Link href="/documents/details" className="inline-flex mt-2 text-sm text-purple-300 hover:underline">
                    View all file details & processing status →
                </Link>
            </div>

            <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                className={`glass rounded-2xl p-8 border-2 border-dashed transition-all ${dragOver ? "border-blue-500/60 bg-blue-500/5" : isDark ? "border-white/15" : "border-slate-300"}`}
            >
                <div className="flex flex-col items-center text-center gap-3">
                    <div className={`h-14 w-14 rounded-2xl flex items-center justify-center ${isDark ? "bg-blue-500/15 text-blue-300" : "bg-blue-100 text-blue-600"}`}>
                        <Upload size={24} />
                    </div>
                    <p className={`font-semibold ${colors.textPrimary}`}>
                        {uploading ? "Uploading…" : "Drag & drop files or folder"}
                    </p>
                    <p className={`text-sm ${colors.textMuted}`}>
                        PDF, images, DOCX, XLSX, PPTX — max 50 MB each · paste with Ctrl+V
                    </p>
                    <div className="flex flex-wrap gap-2 justify-center">
                        <label className="btn-gradient rounded-xl px-5 py-2.5 text-sm cursor-pointer inline-flex items-center gap-2">
                            <Upload size={14} /> Browse files
                            <input
                                type="file"
                                className="hidden"
                                accept={ACCEPT_ATTR}
                                multiple
                                disabled={uploading}
                                onChange={(e) => {
                                    if (e.target.files?.length) addFilesToQueue(e.target.files);
                                    e.target.value = "";
                                }}
                            />
                        </label>
                        <label className="btn-secondary rounded-xl px-5 py-2.5 text-sm cursor-pointer inline-flex items-center gap-2">
                            <FolderUp size={14} /> Upload folder
                            <input
                                type="file"
                                className="hidden"
                                accept={ACCEPT_ATTR}
                                multiple
                                {...({ webkitdirectory: "", directory: "" } as any)}
                                disabled={uploading}
                                onChange={(e) => {
                                    if (e.target.files?.length) addFilesToQueue(e.target.files);
                                    e.target.value = "";
                                }}
                            />
                        </label>
                    </div>
                </div>
            </div>

            {showStaging && (
                <div className="glass rounded-2xl overflow-hidden">
                    <div className={`px-5 py-4 border-b ${colors.borderPrimary} flex flex-wrap items-center justify-between gap-3`}>
                        <div>
                            <h2 className={`text-sm font-semibold ${colors.textPrimary}`}>
                                {uploading ? "Uploading queue" : `Ready to upload (${pendingFiles.length})`}
                            </h2>
                            <p className={`text-xs mt-0.5 ${colors.textMuted}`}>
                                Review files, remove unwanted ones, then click Upload
                            </p>
                        </div>
                        <div className="flex gap-2">
                            {!uploading && pendingFiles.length > 0 && (
                                <button type="button" onClick={clearQueue} className="btn-ghost rounded-xl px-3 py-2 text-sm">
                                    Clear all
                                </button>
                            )}
                            <button
                                type="button"
                                onClick={uploadQueue}
                                disabled={uploading || pendingFiles.length === 0}
                                className="btn-gradient rounded-xl px-5 py-2.5 text-sm inline-flex items-center gap-2 disabled:opacity-50"
                            >
                                {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
                                Upload {pendingFiles.length || queueItems.length} file(s)
                            </button>
                        </div>
                    </div>
                    <ul className="divide-y divide-white/5">
                        {(queueItems.length ? queueItems : pendingFiles.map((p) => ({
                            id: p.id,
                            name: p.file.name,
                            size: p.file.size,
                            mimeType: p.file.type,
                            status: "queued" as QueueItemStatus,
                            error: undefined as string | undefined,
                        }))).map((item) => (
                            <li key={item.id} className={`px-5 py-3 flex flex-wrap items-center justify-between gap-3 ${colors.bgHover}`}>
                                <div className="min-w-0 flex-1">
                                    <p className={`font-medium truncate text-sm ${colors.textPrimary}`}>{item.name}</p>
                                    <p className={`text-xs mt-0.5 ${colors.textMuted}`}>
                                        {formatBytes(item.size)}
                                        {"mimeType" in item && item.mimeType && (
                                            <span className="ml-2">{getFileTypeLabel(item.mimeType, item.name)}</span>
                                        )}
                                    </p>
                                </div>
                                <div className="flex items-center gap-2">
                                    {"status" in item && item.status !== "queued" && (
                                        <span className={`text-xs px-2 py-0.5 rounded-full border ${statusBadge(item.status, isDark)}`}>
                                            {item.status}
                                            {item.error ? `: ${item.error}` : ""}
                                        </span>
                                    )}
                                    {!uploading && pendingFiles.some((p) => p.id === item.id) && (
                                        <button
                                            type="button"
                                            onClick={() => removeFromQueue(item.id)}
                                            className="btn-ghost rounded-lg p-2 text-red-300"
                                            aria-label="Remove from queue"
                                        >
                                            <X size={14} />
                                        </button>
                                    )}
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {error && <div className="rounded-xl border border-red-500/30 bg-red-500/10 text-red-300 px-4 py-3 text-sm">{error}</div>}

            <div className="glass rounded-2xl">
                <div className={`px-5 py-4 border-b ${colors.borderPrimary} flex flex-wrap items-center justify-between gap-3`}>
                    <div className="flex items-center gap-2">
                        <FileText size={16} className={colors.textMuted} />
                        <h2 className={`text-sm font-semibold ${colors.textPrimary}`}>Library</h2>
                        <span className={`text-xs ${colors.textMuted}`}>({pagination.total})</span>
                    </div>
                    <button type="button" onClick={load} className="btn-secondary rounded-xl px-3 py-2 text-sm flex items-center gap-2">
                        <RefreshCw size={14} /> Refresh
                    </button>
                </div>

                <div className={`px-5 py-4 border-b ${colors.borderPrimary} bg-white/[0.02]`}>
                    <div className="flex flex-wrap items-end gap-3">
                        <div className="flex flex-col gap-1 flex-1 min-w-[200px]">
                            <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 ml-0.5">Search</span>
                            <div className="relative">
                                <Search size={16} className={`absolute left-3 top-1/2 -translate-y-1/2 ${colors.textMuted}`} />
                                <input
                                    value={searchInput}
                                    onChange={(e) => setSearchInput(e.target.value)}
                                    onKeyDown={(e) => e.key === "Enter" && applySearch()}
                                    placeholder="Search filename…"
                                    className="w-full premium-input rounded-xl py-2.5 pl-10 pr-4 text-sm"
                                />
                            </div>
                        </div>
                        <FilterSelect
                            label="Sort by"
                            value={sortBy}
                            onChange={(v) => { setSortBy(v); setPage(1); }}
                            options={SORT_OPTIONS}
                            minWidth="min-w-[120px]"
                        />
                        <FilterSelect
                            label="Order"
                            value={sortOrder}
                            onChange={(v) => { setSortOrder(v); setPage(1); }}
                            options={ORDER_OPTIONS}
                            minWidth="min-w-[130px]"
                        />
                        <FilterSelect
                            label="File type"
                            value={fileTypeFilter}
                            onChange={(v) => { setFileTypeFilter(v); setPage(1); }}
                            options={[...FILE_TYPE_OPTIONS]}
                            minWidth="min-w-[150px]"
                        />
                        <FilterSelect
                            label="Duplicates"
                            value={duplicatesOnly}
                            onChange={(v) => { setDuplicatesOnly(v); setPage(1); }}
                            options={DUPLICATE_OPTIONS}
                            minWidth="min-w-[140px]"
                        />
                        <button type="button" onClick={applySearch} className="btn-gradient rounded-xl px-4 py-2.5 text-sm h-[42px] self-end">
                            Search
                        </button>
                    </div>
                </div>

                <div className="overflow-hidden rounded-b-2xl">
                {loading ? (
                    <div className={`p-8 text-sm ${colors.textMuted}`}>Loading…</div>
                ) : docs.length === 0 ? (
                    <div className={`p-8 text-sm ${colors.textMuted}`}>No documents found.</div>
                ) : (
                    <ul className="divide-y divide-white/5">
                        {docs.map((doc) => {
                            const { label: displayStatus, isProcessing } = getDisplayStatus(doc);
                            return (
                            <li key={doc.documentId} className={`px-5 py-4 flex flex-wrap items-center justify-between gap-3 ${colors.bgHover}`}>
                                <div className="min-w-0 flex-1">
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <p className={`font-medium truncate ${colors.textPrimary}`}>{doc.originalFilename}</p>
                                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase border ${statusBadge(displayStatus, isDark)}`}>
                                            {isProcessing && <Loader2 size={10} className="animate-spin" />}
                                            {displayStatus}
                                        </span>
                                        {doc.isDuplicate && (
                                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase bg-amber-500/15 text-amber-300 border border-amber-500/25">
                                                <Copy size={10} /> Duplicate ×{doc.duplicateCount}
                                            </span>
                                        )}
                                    </div>
                                    <p className={`text-xs mt-1 ${colors.textMuted}`}>
                                        <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase mr-2 ${isDark ? "bg-blue-500/15 text-blue-300" : "bg-blue-100 text-blue-700"}`}>
                                            {getFileTypeLabel(doc.mimeType, doc.originalFilename)}
                                        </span>
                                        {formatBytes(doc.sizeBytes)} · {new Date(doc.createdAt).toLocaleString()}
                                        {doc.classification && ` · ${doc.classification}`}
                                    </p>
                                    {doc.aiErrorMessage && (
                                        <p className="text-xs text-red-400 mt-1">{doc.aiErrorMessage}</p>
                                    )}
                                </div>
                                <div className="flex gap-2 flex-wrap">
                                    <Link href={`/documents/details?doc=${doc.documentId}`} className="btn-secondary rounded-lg px-3 py-2 text-sm flex items-center gap-1.5">
                                        <Info size={14} /> Details
                                    </Link>
                                    <Link href={`/documents/${doc.documentId}`} className="btn-secondary rounded-lg px-3 py-2 text-sm flex items-center gap-1.5">
                                        <Eye size={14} /> Preview
                                    </Link>
                                    <button type="button" onClick={() => remove(doc.documentId, doc.originalFilename)}
                                        className="btn-ghost rounded-lg px-3 py-2 text-sm flex items-center gap-1.5 text-red-300">
                                        <Trash2 size={14} /> Delete
                                    </button>
                                </div>
                            </li>
                        );})}
                    </ul>
                )}
                </div>

                <LibraryPagination
                    page={pagination.page}
                    limit={pagination.limit}
                    total={pagination.total}
                    totalPages={pagination.totalPages}
                    onPageChange={setPage}
                    onLimitChange={(limit) => { setPageLimit(limit); setPage(1); }}
                    borderClass={colors.borderPrimary}
                    textMutedClass={colors.textMuted}
                />
            </div>
        </div>
    );
}

export default function DocumentsPage() {
    return (
        <ClientLayout>
            <DocumentsContent />
        </ClientLayout>
    );
}
