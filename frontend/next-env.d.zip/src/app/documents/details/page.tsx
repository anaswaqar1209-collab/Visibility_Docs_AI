"use client";

import React, { Suspense, useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { ArrowLeft, Loader2, CheckCircle2, XCircle, Clock } from "lucide-react";
import ClientLayout from "@/components/ClientLayout";
import { useTheme } from "@/context/ColorContext";
import { apiRequest } from "@/lib/apiClient";
import { getFileTypeLabel } from "@/lib/fileValidation";

type DocIntel = {
    document: {
        documentId: string;
        originalFilename: string;
        mimeType: string;
        sizeBytes: number;
        status: string;
        storagePath?: string;
        pythonDocumentId?: string | null;
        aiErrorMessage?: string | null;
        classification?: string | null;
        createdAt: string;
    };
    aiDocument?: Record<string, unknown> | null;
    validations?: unknown[];
};

type Summary = { total: number; processing: number; ready: number; failed: number };

function formatBytes(n: number) {
    if (!n) return "—";
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function statusLabel(status: string) {
    if (status === "ready") return "Complete";
    if (status === "failed") return "Failed";
    if (status === "processing" || status === "uploaded") return "Processing";
    return status;
}

function AllFilesDetailsContent() {
    const { theme } = useTheme();
    const colors = theme.colors;
    const isDark = theme.name === "dark";
    const searchParams = useSearchParams();
    const highlightId = searchParams.get("doc");

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [summary, setSummary] = useState<Summary>({ total: 0, processing: 0, ready: 0, failed: 0 });
    const [documents, setDocuments] = useState<DocIntel[]>([]);

    const load = useCallback(async () => {
        setError(null);
        try {
            const data = await apiRequest("/docs/documents/intelligence/all");
            setSummary(data?.data?.summary || { total: 0, processing: 0, ready: 0, failed: 0 });
            setDocuments(data?.data?.documents || []);
        } catch (e: any) {
            setError(e.message || "Failed to load file details");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => { load(); }, [load]);

    const hasProcessing = summary.processing > 0;
    useEffect(() => {
        if (!hasProcessing) return;
        const interval = setInterval(load, 5000);
        return () => clearInterval(interval);
    }, [hasProcessing, load]);

    useEffect(() => {
        if (!highlightId) return;
        document.getElementById(`doc-${highlightId}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, [highlightId, documents]);

    return (
        <div className="p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
            <Link href="/documents" className={`inline-flex items-center gap-2 text-sm ${colors.textMuted} hover:text-white`}>
                <ArrowLeft size={14} /> Back to upload
            </Link>
            <div>
                <h1 className={`text-2xl font-bold ${colors.textPrimary}`}>All file details</h1>
                <p className={`text-sm mt-1 ${colors.textMuted}`}>
                    Files upload to Node, then forward to the AI model. Processing shows until the model responds.
                </p>
            </div>
            {hasProcessing && (
                <div className={`flex items-center gap-2 text-xs glass rounded-xl px-4 py-3 ${colors.textMuted}`}>
                    <Loader2 size={14} className="animate-spin text-amber-400" />
                    Auto-refreshing every 5 seconds while files are processing…
                </div>
            )}
            {error && <div className="text-red-300 text-sm">{error}</div>}
            {loading ? (
                <div className={`flex items-center gap-2 text-sm ${colors.textMuted}`}>
                    <Loader2 size={16} className="animate-spin" /> Loading…
                </div>
            ) : (
                <>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        <div className="glass rounded-xl p-4 text-center">
                            <p className={`text-2xl font-bold ${colors.textPrimary}`}>{summary.total}</p>
                            <p className={`text-xs mt-1 ${colors.textMuted}`}>Total</p>
                        </div>
                        <div className="glass rounded-xl p-4 text-center border border-amber-500/20">
                            <p className="text-2xl font-bold text-amber-300">{summary.processing}</p>
                            <p className={`text-xs mt-1 ${colors.textMuted}`}>Processing</p>
                        </div>
                        <div className="glass rounded-xl p-4 text-center border border-green-500/20">
                            <p className="text-2xl font-bold text-green-300">{summary.ready}</p>
                            <p className={`text-xs mt-1 ${colors.textMuted}`}>Complete</p>
                        </div>
                        <div className="glass rounded-xl p-4 text-center border border-red-500/20">
                            <p className="text-2xl font-bold text-red-300">{summary.failed}</p>
                            <p className={`text-xs mt-1 ${colors.textMuted}`}>Failed</p>
                        </div>
                    </div>
                    <div className="space-y-4">
                        {documents.map((item) => {
                            const doc = item.document;
                            const isProcessing = doc.status === "processing" || doc.status === "uploaded";
                            const isReady = doc.status === "ready";
                            const isFailed = doc.status === "failed";
                            const ai = item.aiDocument;
                            return (
                                <div
                                    key={doc.documentId}
                                    id={`doc-${doc.documentId}`}
                                    className={`glass rounded-2xl p-5 space-y-4 ${highlightId === doc.documentId ? "ring-2 ring-purple-500/50" : ""}`}
                                >
                                    <div className="flex flex-wrap justify-between gap-3">
                                        <div>
                                            <h2 className={`font-semibold ${colors.textPrimary}`}>{doc.originalFilename}</h2>
                                            <p className={`text-xs mt-1 ${colors.textMuted}`}>
                                                {getFileTypeLabel(doc.mimeType, doc.originalFilename)} · {formatBytes(doc.sizeBytes)} · {new Date(doc.createdAt).toLocaleString()}
                                            </p>
                                        </div>
                                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase ${
                                            isReady ? "bg-green-500/15 text-green-300" : isFailed ? "bg-red-500/15 text-red-300" : "bg-amber-500/15 text-amber-300"
                                        }`}>
                                            {isProcessing && <Loader2 size={12} className="animate-spin" />}
                                            {isReady && <CheckCircle2 size={12} />}
                                            {isFailed && <XCircle size={12} />}
                                            {!isProcessing && !isReady && !isFailed && <Clock size={12} />}
                                            {statusLabel(doc.status)}
                                        </span>
                                    </div>
                                    {isProcessing && (
                                        <div className="rounded-xl p-4 text-sm bg-amber-500/10 text-amber-200">
                                            <p className="font-medium">Sent to AI model — waiting for response…</p>
                                            {doc.pythonDocumentId && <p className="text-xs mt-2 font-mono opacity-70">Model ID: {doc.pythonDocumentId}</p>}
                                        </div>
                                    )}
                                    {isFailed && (
                                        <div className="rounded-xl p-4 text-sm bg-red-500/10 text-red-300">
                                            {doc.aiErrorMessage || "AI model returned an error."}
                                        </div>
                                    )}
                                    {isReady && (
                                        <dl className="grid sm:grid-cols-2 gap-3 text-sm">
                                            <div><dt className={colors.textMuted}>Type</dt><dd>{String(ai?.document_type || doc.classification || "—")}</dd></div>
                                            <div><dt className={colors.textMuted}>Pages</dt><dd>{String(ai?.page_count ?? "—")}</dd></div>
                                            <div className="sm:col-span-2"><dt className={colors.textMuted}>Storage</dt><dd className="font-mono text-xs break-all">{doc.storagePath || "—"}</dd></div>
                                            {Boolean(ai?.extracted_data || ai?.cv_extraction_data) && (
                                                <div className="sm:col-span-2">
                                                    <dt className={colors.textMuted}>Extracted data</dt>
                                                    <pre className={`text-xs rounded-xl p-3 mt-1 max-h-40 overflow-auto ${isDark ? "bg-black/30" : "bg-slate-100"}`}>
                                                        {JSON.stringify(ai?.extracted_data || ai?.cv_extraction_data, null, 2)}
                                                    </pre>
                                                </div>
                                            )}
                                        </dl>
                                    )}
                                    <Link href={`/documents/${doc.documentId}`} className="btn-secondary rounded-lg px-3 py-2 text-xs inline-block">Preview</Link>
                                </div>
                            );
                        })}
                    </div>
                </>
            )}
        </div>
    );
}

export default function AllFilesDetailsPage() {
    return (
        <ClientLayout>
            <Suspense fallback={<div className="p-8 text-sm text-slate-400">Loading…</div>}>
                <AllFilesDetailsContent />
            </Suspense>
        </ClientLayout>
    );
}
