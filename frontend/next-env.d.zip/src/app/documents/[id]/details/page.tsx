"use client";

import React, { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { ArrowLeft, Download, Eye, Loader2 } from "lucide-react";
import ClientLayout from "@/components/ClientLayout";
import { useTheme } from "@/context/ColorContext";
import { apiRequest } from "@/lib/apiClient";
import { getDocumentDownloadUrl, getDocumentPreviewUrl } from "@/lib/documents";

type TabId = "overview" | "processing" | "extraction" | "validations";

function formatBytes(n: number) {
    if (!n) return "—";
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function JsonBlock({ data, isDark }: { data: unknown; isDark: boolean }) {
    if (!data || (typeof data === "object" && Object.keys(data as object).length === 0)) {
        return <p className="text-sm text-slate-400">No data available.</p>;
    }
    return (
        <pre className={`text-xs rounded-xl p-4 overflow-x-auto ${isDark ? "bg-black/30" : "bg-slate-100"}`}>
            {JSON.stringify(data, null, 2)}
        </pre>
    );
}

function DocumentDetailsContent() {
    const params = useParams();
    const id = params?.id as string;
    const { theme } = useTheme();
    const colors = theme.colors;
    const isDark = theme.name === "dark";

    const [tab, setTab] = useState<TabId>("overview");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [intel, setIntel] = useState<any>(null);

    const load = useCallback(async () => {
        if (!id) return;
        setError(null);
        try {
            const data = await apiRequest(`/docs/documents/${id}/intelligence`);
            setIntel(data?.data || null);
        } catch (e: any) {
            setError(e.message || "Failed to load document intelligence");
        } finally {
            setLoading(false);
        }
    }, [id]);

    useEffect(() => {
        setLoading(true);
        load();
    }, [load]);

    const doc = intel?.document;
    const aiDoc = intel?.aiDocument;
    const job = intel?.job;
    const validations = intel?.validations || [];

    const isProcessing =
        doc?.status === "processing" ||
        doc?.status === "uploaded" ||
        String(job?.status || "").toLowerCase().includes("process");

    useEffect(() => {
        if (!isProcessing || tab !== "processing") return;
        const interval = setInterval(load, 5000);
        return () => clearInterval(interval);
    }, [isProcessing, tab, load]);

    const tabs: { id: TabId; label: string }[] = [
        { id: "overview", label: "Overview" },
        { id: "processing", label: "Processing" },
        { id: "extraction", label: "Extraction" },
        { id: "validations", label: "Validations" },
    ];

    const downloadUrl = id ? getDocumentDownloadUrl(id) : "";
    const previewApiUrl = id ? getDocumentPreviewUrl(id) : "";
    const previewPageUrl = id ? `/documents/${id}` : "";

    return (
        <div className="p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
            <Link href="/documents" className={`inline-flex items-center gap-2 text-sm ${colors.textMuted} hover:text-white`}>
                <ArrowLeft size={14} /> Back to library
            </Link>

            {loading && !doc && (
                <div className={`flex items-center gap-2 text-sm ${colors.textMuted}`}>
                    <Loader2 size={16} className="animate-spin" /> Loading document details…
                </div>
            )}
            {error && <div className="text-red-300 text-sm">{error}</div>}

            {doc && (
                <>
                    <div className="flex flex-wrap items-start justify-between gap-4">
                        <div>
                            <h1 className={`text-2xl font-bold ${colors.textPrimary}`}>{doc.originalFilename}</h1>
                            <p className={`text-sm mt-1 ${colors.textMuted}`}>
                                {doc.mimeType} · {doc.status}
                                {doc.aiProcessingStatus && ` · AI: ${doc.aiProcessingStatus}`}
                            </p>
                        </div>
                        <div className="flex gap-2 flex-wrap">
                            <Link href={`/documents/${id}`} className="btn-secondary rounded-xl px-4 py-2.5 text-sm flex items-center gap-2">
                                <Eye size={14} /> Preview
                            </Link>
                            <a href={downloadUrl} className="btn-secondary rounded-xl px-4 py-2.5 text-sm flex items-center gap-2">
                                <Download size={14} /> Download
                            </a>
                        </div>
                    </div>

                    <div className={`flex flex-wrap gap-1 border-b ${colors.borderPrimary}`}>
                        {tabs.map((t) => (
                            <button
                                key={t.id}
                                type="button"
                                onClick={() => setTab(t.id)}
                                className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors ${
                                    tab === t.id
                                        ? "border-purple-400 text-purple-300"
                                        : `border-transparent ${colors.textMuted} hover:text-white`
                                }`}
                            >
                                {t.label}
                                {t.id === "processing" && isProcessing && (
                                    <Loader2 size={12} className="inline ml-1.5 animate-spin" />
                                )}
                            </button>
                        ))}
                    </div>

                    <div className="glass rounded-2xl p-6">
                        {tab === "overview" && (
                            <dl className="grid sm:grid-cols-2 gap-4 text-sm">
                                <div>
                                    <dt className={colors.textMuted}>Filename</dt>
                                    <dd className={colors.textPrimary}>{doc.originalFilename}</dd>
                                </div>
                                <div>
                                    <dt className={colors.textMuted}>Status</dt>
                                    <dd className={colors.textPrimary}>{doc.status}</dd>
                                </div>
                                <div>
                                    <dt className={colors.textMuted}>Size</dt>
                                    <dd className={colors.textPrimary}>{formatBytes(doc.sizeBytes)}</dd>
                                </div>
                                <div>
                                    <dt className={colors.textMuted}>Uploaded</dt>
                                    <dd className={colors.textPrimary}>{new Date(doc.createdAt).toLocaleString()}</dd>
                                </div>
                                <div>
                                    <dt className={colors.textMuted}>Organization</dt>
                                    <dd className={colors.textPrimary}>{doc.organizationId || "Personal"}</dd>
                                </div>
                                <div>
                                    <dt className={colors.textMuted}>Python document ID</dt>
                                    <dd className={`${colors.textPrimary} font-mono text-xs break-all`}>
                                        {doc.pythonDocumentId || "—"}
                                    </dd>
                                </div>
                                <div>
                                    <dt className={colors.textMuted}>Document type</dt>
                                    <dd className={colors.textPrimary}>
                                        {aiDoc?.document_type || doc.classification || "—"}
                                    </dd>
                                </div>
                                <div>
                                    <dt className={colors.textMuted}>Page count</dt>
                                    <dd className={colors.textPrimary}>{aiDoc?.page_count ?? doc.pageCount ?? "—"}</dd>
                                </div>
                                <div className="sm:col-span-2">
                                    <dt className={colors.textMuted}>Storage path (server)</dt>
                                    <dd className={`${colors.textPrimary} font-mono text-xs break-all`}>
                                        {doc.storagePath || "—"}
                                    </dd>
                                </div>
                                <div className="sm:col-span-2">
                                    <dt className={colors.textMuted}>Preview page</dt>
                                    <dd>
                                        <Link href={previewPageUrl} className="text-purple-300 hover:underline text-xs break-all">
                                            {typeof window !== "undefined" ? `${window.location.origin}${previewPageUrl}` : previewPageUrl}
                                        </Link>
                                    </dd>
                                </div>
                                <div className="sm:col-span-2">
                                    <dt className={colors.textMuted}>API preview URL</dt>
                                    <dd className={`${colors.textPrimary} font-mono text-xs break-all`}>{previewApiUrl || "—"}</dd>
                                </div>
                                <div className="sm:col-span-2">
                                    <dt className={colors.textMuted}>API download URL</dt>
                                    <dd className={`${colors.textPrimary} font-mono text-xs break-all`}>{downloadUrl || "—"}</dd>
                                </div>
                                {doc.aiErrorMessage && (
                                    <div className="sm:col-span-2">
                                        <dt className="text-red-400">AI error</dt>
                                        <dd className="text-red-300">{doc.aiErrorMessage}</dd>
                                    </div>
                                )}
                                {aiDoc?.error_message && (
                                    <div className="sm:col-span-2">
                                        <dt className="text-red-400">Processing error</dt>
                                        <dd className="text-red-300">{String(aiDoc.error_message)}</dd>
                                    </div>
                                )}
                            </dl>
                        )}

                        {tab === "processing" && (
                            <div className="space-y-4">
                                {!doc.pythonDocumentId ? (
                                    <p className={`text-sm ${colors.textMuted}`}>
                                        Document was not forwarded to the AI service yet.
                                    </p>
                                ) : (
                                    <>
                                        {isProcessing && (
                                            <p className={`text-xs flex items-center gap-2 ${colors.textMuted}`}>
                                                <Loader2 size={12} className="animate-spin" /> Auto-refreshing every 5s…
                                            </p>
                                        )}
                                        <JsonBlock data={job} isDark={isDark} />
                                        {job?.stages && Array.isArray(job.stages) && (
                                            <ol className="space-y-2 mt-4">
                                                {job.stages.map((stage: any, i: number) => (
                                                    <li
                                                        key={i}
                                                        className={`flex items-center gap-3 text-sm rounded-lg px-3 py-2 ${isDark ? "bg-white/5" : "bg-slate-100"}`}
                                                    >
                                                        <span className={`w-2 h-2 rounded-full ${
                                                            stage.status === "completed" ? "bg-green-400" :
                                                            stage.status === "failed" ? "bg-red-400" :
                                                            stage.status === "running" ? "bg-amber-400 animate-pulse" :
                                                            "bg-slate-500"
                                                        }`} />
                                                        <span className={colors.textPrimary}>{stage.name || stage.stage}</span>
                                                        <span className={`text-xs ${colors.textMuted}`}>{stage.status}</span>
                                                    </li>
                                                ))}
                                            </ol>
                                        )}
                                    </>
                                )}
                            </div>
                        )}

                        {tab === "extraction" && (
                            <div className="space-y-4">
                                <dl className="grid sm:grid-cols-2 gap-4 text-sm">
                                    <div>
                                        <dt className={colors.textMuted}>Document type</dt>
                                        <dd className={colors.textPrimary}>{aiDoc?.document_type || "—"}</dd>
                                    </div>
                                    <div>
                                        <dt className={colors.textMuted}>Phase 3 agent</dt>
                                        <dd className={colors.textPrimary}>{aiDoc?.phase3_agent || "—"}</dd>
                                    </div>
                                    {aiDoc?.cv_score != null && (
                                        <div>
                                            <dt className={colors.textMuted}>CV score</dt>
                                            <dd className={colors.textPrimary}>{String(aiDoc.cv_score)}</dd>
                                        </div>
                                    )}
                                </dl>
                                {aiDoc?.cv_extraction_data && (
                                    <div>
                                        <h3 className={`text-sm font-semibold mb-2 ${colors.textPrimary}`}>CV extraction</h3>
                                        <JsonBlock data={aiDoc.cv_extraction_data} isDark={isDark} />
                                    </div>
                                )}
                                {aiDoc?.extracted_data && (
                                    <div>
                                        <h3 className={`text-sm font-semibold mb-2 ${colors.textPrimary}`}>Extracted data</h3>
                                        <JsonBlock data={aiDoc.extracted_data} isDark={isDark} />
                                    </div>
                                )}
                                {!aiDoc?.extracted_data && !aiDoc?.cv_extraction_data && aiDoc?.raw_text && (
                                    <div>
                                        <h3 className={`text-sm font-semibold mb-2 ${colors.textPrimary}`}>Raw text (preview)</h3>
                                        <p className={`text-xs whitespace-pre-wrap max-h-64 overflow-y-auto rounded-xl p-4 ${isDark ? "bg-black/30" : "bg-slate-100"}`}>
                                            {String(aiDoc.raw_text).slice(0, 4000)}
                                            {String(aiDoc.raw_text).length > 4000 && "…"}
                                        </p>
                                    </div>
                                )}
                                {!aiDoc && (
                                    <p className={`text-sm ${colors.textMuted}`}>No extraction data from AI service yet.</p>
                                )}
                            </div>
                        )}

                        {tab === "validations" && (
                            <div className="space-y-4">
                                {validations.length === 0 ? (
                                    <p className={`text-sm ${colors.textMuted}`}>No validation results for this document.</p>
                                ) : (
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm">
                                            <thead>
                                                <tr className={`text-left border-b ${colors.borderPrimary}`}>
                                                    <th className={`py-2 pr-4 ${colors.textMuted}`}>Rule</th>
                                                    <th className={`py-2 pr-4 ${colors.textMuted}`}>Status</th>
                                                    <th className={`py-2 ${colors.textMuted}`}>Details</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {validations.map((v: any, i: number) => (
                                                    <tr key={i} className={`border-b ${colors.borderPrimary}`}>
                                                        <td className={`py-3 pr-4 ${colors.textPrimary}`}>
                                                            {v.rule_name || v.validation_type || v.type || "—"}
                                                        </td>
                                                        <td className="py-3 pr-4">
                                                            <span className={`text-xs px-2 py-0.5 rounded-full ${
                                                                (v.status || v.result) === "pass" || v.passed
                                                                    ? "bg-green-500/15 text-green-300"
                                                                    : "bg-red-500/15 text-red-300"
                                                            }`}>
                                                                {v.status || v.result || (v.passed ? "pass" : "fail")}
                                                            </span>
                                                        </td>
                                                        <td className={`py-3 text-xs ${colors.textMuted}`}>
                                                            {v.message || v.details || JSON.stringify(v).slice(0, 120)}
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </>
            )}
        </div>
    );
}

export default function DocumentDetailsPage() {
    return (
        <ClientLayout>
            <DocumentDetailsContent />
        </ClientLayout>
    );
}
