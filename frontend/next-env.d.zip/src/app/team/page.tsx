"use client";

import React, { useCallback, useEffect, useState } from "react";
import { AlertTriangle, Loader2, Plus, RefreshCw, UserCheck, UserX } from "lucide-react";
import ClientLayout from "@/components/ClientLayout";
import { useToast } from "@/components/Toast";
import { useTheme } from "@/context/ColorContext";
import { apiRequest } from "@/lib/apiClient";
import { enrichUserFromToken } from "@/lib/auth";
import { getAuthValue, getStoredUser } from "@/lib/authSession";

const PERM_LABELS: Record<string, string> = {
    "document.upload": "Upload",
    "document.view": "View",
    "document.delete": "Delete",
    "document.preview": "Preview",
    "chat.use": "Chat",
    "team.manage": "Manage team",
    "org.documents.view": "View org documents",
};

type Member = {
    userId: string;
    fullName: string;
    email: string;
    status: string;
    permissions?: Record<string, boolean>;
};

function TeamContent() {
    const { theme } = useTheme();
    const colors = theme.colors;
    const { showToast } = useToast();
    const [members, setMembers] = useState<Member[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);
    const [showForm, setShowForm] = useState(false);
    const [creating, setCreating] = useState(false);
    const [form, setForm] = useState({ fullName: "", email: "", password: "" });
    const [editingPerms, setEditingPerms] = useState<string | null>(null);
    const [hasOrganization, setHasOrganization] = useState(true);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const data = await apiRequest("/docs/team/members");
            setMembers(data?.data?.members || []);
            setError(null);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        const token = getAuthValue("accessToken") || getAuthValue("token");
        const stored = getStoredUser<any>();
        const user = enrichUserFromToken(stored, token);
        setHasOrganization(!!user?.organizationId);

        (async () => {
            try {
                const me = await apiRequest("/auth/me");
                const orgId = me?.data?.user?.organizationId;
                if (orgId !== undefined) setHasOrganization(!!orgId);
            } catch {
                // keep stored-user fallback
            }
        })();
    }, []);

    useEffect(() => { load(); }, [load]);

    const createMember = async (e: React.FormEvent) => {
        e.preventDefault();
        setCreating(true);
        setError(null);
        setSuccess(null);
        try {
            const data = await apiRequest("/docs/team/members", { method: "POST", body: JSON.stringify(form) });
            setForm({ fullName: "", email: "", password: "" });
            setShowForm(false);
            const msg = data?.message
                || (data?.data?.openRemoteSynced
                    ? "Member created in OpenRemote and database"
                    : "Member created in database only (OpenRemote unavailable)");
            setSuccess(msg);
            showToast(msg, "success");
            await load();
        } catch (e: any) {
            const msg = e.message || "Failed to create team member";
            setError(msg);
            showToast(msg, "error");
        } finally {
            setCreating(false);
        }
    };

    const toggleStatus = async (userId: string, status: string) => {
        const next = status === "active" ? "blocked" : "active";
        await apiRequest(`/docs/team/members/${userId}/status`, { method: "PATCH", body: JSON.stringify({ status: next }) });
        await load();
    };

    const savePermissions = async (userId: string, permissions: Record<string, boolean>) => {
        await apiRequest(`/docs/team/members/${userId}/permissions`, { method: "PATCH", body: JSON.stringify({ permissions }) });
        setEditingPerms(null);
        await load();
    };

    const removeMember = async (userId: string) => {
        if (!confirm("Remove this team member?")) return;
        await apiRequest(`/docs/team/members/${userId}`, { method: "DELETE" });
        await load();
    };

    return (
        <div className="p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className={`text-2xl font-bold ${colors.textPrimary}`}>Team</h1>
                    <p className={`text-sm ${colors.textMuted}`}>Add members and set permissions</p>
                </div>
                <div className="flex gap-2">
                    <button type="button" onClick={load} className="btn-secondary rounded-xl px-4 py-2 text-sm"><RefreshCw size={14} className="inline mr-1" />Refresh</button>
                    <button type="button" onClick={() => setShowForm(!showForm)} className="btn-gradient rounded-xl px-4 py-2 text-sm" disabled={!hasOrganization}><Plus size={14} className="inline mr-1" />Add member</button>
                </div>
            </div>

            {!hasOrganization && (
                <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-200 flex items-start gap-2">
                    <AlertTriangle size={16} className="shrink-0 mt-0.5" />
                    <div>
                        <p className="font-medium">No organization linked to this admin account</p>
                        <p className="text-amber-200/80 mt-1">
                            Team members cannot be created until an organization is assigned. Run the seed script or contact a super admin.
                        </p>
                    </div>
                </div>
            )}

            {error && <div className="rounded-xl border border-red-500/30 bg-red-500/10 text-red-300 px-4 py-3 text-sm">{error}</div>}
            {success && <div className="rounded-xl border border-green-500/30 bg-green-500/10 text-green-300 px-4 py-3 text-sm">{success}</div>}

            {showForm && hasOrganization && (
                <form onSubmit={createMember} className="glass rounded-2xl p-6 space-y-4">
                    <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 ml-0.5">Full name</span>
                        <input
                            className="w-full premium-input rounded-xl px-4 py-3 text-sm h-[42px]"
                            placeholder="Jane Doe"
                            value={form.fullName}
                            onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                            autoComplete="name"
                            required
                        />
                    </div>
                    <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 ml-0.5">Email</span>
                        <input
                            className="w-full premium-input rounded-xl px-4 py-3 text-sm h-[42px]"
                            placeholder="member@company.com"
                            type="email"
                            value={form.email}
                            onChange={(e) => setForm({ ...form, email: e.target.value })}
                            autoComplete="off"
                            required
                        />
                    </div>
                    <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 ml-0.5">Password</span>
                        <input
                            className="w-full premium-input rounded-xl px-4 py-3 text-sm h-[42px]"
                            placeholder="Temporary password"
                            type="password"
                            value={form.password}
                            onChange={(e) => setForm({ ...form, password: e.target.value })}
                            autoComplete="new-password"
                            required
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={creating}
                        className="btn-gradient rounded-xl px-4 py-2.5 text-sm inline-flex items-center gap-2 disabled:opacity-50"
                    >
                        {creating && <Loader2 size={14} className="animate-spin" />}
                        {creating ? "Creating…" : "Create team member"}
                    </button>
                </form>
            )}

            <div className="glass rounded-2xl overflow-hidden">
                {loading ? <div className={`p-8 text-sm ${colors.textMuted}`}>Loading…</div> : (
                    <ul className="divide-y divide-white/5">
                        {members.map((m) => (
                            <li key={m.userId} className="p-5 space-y-3">
                                <div className="flex flex-wrap justify-between gap-3">
                                    <div>
                                        <p className={`font-semibold ${colors.textPrimary}`}>{m.fullName}</p>
                                        <p className={`text-sm ${colors.textMuted}`}>{m.email} · <span className={m.status === "active" ? "text-green-400" : "text-red-400"}>{m.status}</span></p>
                                    </div>
                                    <div className="flex gap-2">
                                        <button type="button" onClick={() => toggleStatus(m.userId, m.status)} className="btn-secondary rounded-lg px-3 py-2 text-sm">
                                            {m.status === "active" ? <><UserX size={14} className="inline" /> Deactivate</> : <><UserCheck size={14} className="inline" /> Activate</>}
                                        </button>
                                        <button type="button" onClick={() => setEditingPerms(editingPerms === m.userId ? null : m.userId)} className="btn-secondary rounded-lg px-3 py-2 text-sm">Permissions</button>
                                        <button type="button" onClick={() => removeMember(m.userId)} className="btn-ghost text-red-300 rounded-lg px-3 py-2 text-sm">Remove</button>
                                    </div>
                                </div>
                                {editingPerms === m.userId && (
                                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2">
                                        {Object.entries(PERM_LABELS).map(([key, label]) => (
                                            <label key={key} className={`flex items-center gap-2 text-sm ${colors.textSecondary}`}>
                                                <input type="checkbox" checked={m.permissions?.[key] ?? false}
                                                    onChange={(e) => {
                                                        const next = { ...m.permissions, [key]: e.target.checked };
                                                        savePermissions(m.userId, next);
                                                    }} />
                                                {label}
                                            </label>
                                        ))}
                                    </div>
                                )}
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
}

export default function TeamPage() {
    return <ClientLayout><TeamContent /></ClientLayout>;
}
